<?php
   
   include("dbConnection.php");


?>
<nav class="navbar navbar-expand-md navbar-dark bg-dark  fixed-top">
     <div class="logo"><a href="#"><img src="images/img/logo/Xoxo.png"></a></div>
    <div class="container">
        
          <link href="https://fonts.googleapis.com/css?family=Great+Vibes|Roboto" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Cookie|Great+Vibes|Handlee|Lobster|Roboto" rel="stylesheet">
        
    <a class="navbar-brand" href="index.php" style="font-family: 'Great Vibes', cursive;">Wish A Sprinkle</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse col-xl-6" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php" style="font-family: 'Lobster', cursive;">Home <span class="sr-only">(current)</span></a>
            </li>
            
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-family: 'Lobster', cursive;">Occasion</a>
                <div class="dropdown-menu" aria-labelledby="dropdown01">
                    <a class="dropdown-item" href="BirthdayCakes.php" style="font-family: 'Lobster', cursive;">Birthday Cakes</a>
                    <a class="dropdown-item" href="Seasanol_Greetings.php" style="font-family: 'Lobster', cursive;">Seasonal Greeing Cakes</a>
                    <a class="dropdown-item" href="Thank_you.php" style="font-family: 'Lobster', cursive;">Thank You Cakes</a>
                    <a class="dropdown-item" href="Anniversary.php" style="font-family: 'Lobster', cursive;">Anniversary Cakes</a>
                    <a class="dropdown-item" href="get_well_soon.php" style="font-family: 'Lobster', cursive;">Get Well Soon Cakes</a>
                    <a class="dropdown-item" href="congragulation.php" style="font-family: 'Lobster', cursive;">Congragulation Cakes</a>
                      <a class="dropdown-item" href="sorry.php" style="font-family: 'Lobster', cursive;">Sorry Cakes</a>
                    <a class="dropdown-item" href="love.php" style="font-family: 'Lobster', cursive;">Loves Cakes</a>
                    <a class="dropdown-item" href="Thinking_of_you.php" style="font-family: 'Lobster', cursive;">Thinking Of You Cakes</a>
                    <a class="dropdown-item" href="Best_Wishes.php" style="font-family: 'Lobster', cursive;">Best Wishes Cake</a>
                    <a class="dropdown-item" href="sympathy.php" style="font-family: 'Lobster', cursive;">Sympathy Cakes</a>
                </div>
            </li>
           <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-family: 'Lobster', cursive;">Account</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item" href="signup.php" style="font-family: 'Lobster', cursive;">Sign Up</a>
                        <a class="dropdown-item" href="login.php" style="font-family: 'Lobster', cursive;">Login</a>
                        <a class="dropdown-item" href="logout.php" style="font-family: 'Lobster', cursive;">Logout</a>
                        <div class="dropdown-divider"></div>    
                    </div>
                </li>
            
              <li class="nav-item active">
                <a class="nav-link" href="#CARTModel" data-toggle="modal" data-target="#exampleModal" style="font-family: 'Lobster', cursive;">Cart   </a>
            </li>
             
        </ul>
        </div>
    </div>
</nav>

    
        
       
        
        
        