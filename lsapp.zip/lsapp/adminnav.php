
<nav class="navbar navbar-expand-md navbar-dark bg-dark  fixed-top">
     <div class="logo"><a href="#"><img src="images/img/logo/Xoxo.png"></a></div>
    <div class="container">
        
        <link href="https://fonts.googleapis.com/css?family=Great+Vibes|Roboto" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Cookie|Great+Vibes|Roboto" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Cookie|Great+Vibes|Handlee|Lobster|Roboto" rel="stylesheet">
       
    <a class="navbar-brand" href="#"  style="font-family: 'Great Vibes', cursive;">Wish A Sprinkle</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php" style="font-family: 'Lobster', cursive;">Home <span class="sr-only">(current)</span></a>
            </li>
            
            
            
            <li class="nav-item">
                <a class="nav-link" href="addproduct.php" style="font-family: 'Lobster', cursive;" >Add product</a>
            </li>
             <li class="nav-item">
                <a class="nav-link" href="adminAllcakes.php" style="font-family: 'Lobster', cursive;" >Cakes</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminfeedback.php" style="font-family: 'Lobster', cursive;" >Feedback</a>
            </li>
           
             <li class="nav-item">
                <a class="nav-link" href="admincontact.php" style="font-family: 'Lobster', cursive;" >Contact Query</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="customerreg.php" style="font-family: 'Lobster', cursive;" >Customer details</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminorders.php" style="font-family: 'Lobster', cursive;" >Orders</a>
            </li>
             <li class="nav-item">
                <a class="nav-link" href="adminregister.php" style="font-family: 'Lobster', cursive;" >Register</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="adminlogout.php" style="font-family: 'Lobster', cursive;" >Logout</a>
            </li>
             
            
        </ul>
        </div>
    </div>
</nav>

                             