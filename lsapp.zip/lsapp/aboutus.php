<?php 

    include("dbconnection.php");



?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/favicon.png">
    <title>Wish A Sprinkle</title>
    
    <!--Template based on URL below-->
    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/starter-template/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- Place your stylesheet here-->
    <link href="/css/stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>
             
             <?php include("nav.php");?><br><br><br><br><br>
     
    <main role="main" class="container">
        <div >
                
            <h2 style="font-family: 'Cookie', cursive; color:#FF7F50;" align="left"> <b><u>About Us</u></b></h2><br>
                
                
                
                
                
            </div>
       
        
        
      <div> <img src="images/ab/hy1.jpg" width="200" height="200">
          <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-110"> </div>
          <p aligh="left" style="color:	#BDB76B;"><b>WHY DO WE DO IT? BECAUSE WE LOVE IT!! </b><br></p>

          <p aligh="left">In 2010, Wish A Sprinkles opened its first kiosk location in this town. From its inception, Sprinkles is known as bakery unique for our square cupcakes and cakes. We take pride in using natural ingredients in our cupcakes, cakes and desserts. Our treats are as deliciously wholesome as they are beautifully decorated. Choose from our signature cupcakes, weekly and holiday specials or custom created desserts.</p></div><br>
        
         <div> <img src="images/ab/vision.png" width="200" height="200">
          <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-110"> </div>
             <p aligh="left" style="color:	#BDB76B;"><b>OUR VISION  </b><br></p>

        <p aligh="left"> Wish A Sprinkles offers a homestyle bakery experience in the whole town. Our vision is to create upscale, quick-serve bakery with a focus on simple and satisfying souther style desserts and baked goods.</p></div><br>
        
         <div> <img src="images/ab/mission.png" width="200" height="200">
          <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-110"> </div>
             <p aligh="left" style="color:	#BDB76B;"><b>OUR MISSION  </b><br></p>

         <p aligh="left">Wish A Sprinkle's philosophy is to offer simple and delicious desserts that are easily accessible to clients via location or delivery options. Our ingredients are high quality; each dessert is carefully made with only the finest, all-natural ingredients.</p></div><br>
        
        
         <div> <img src="images/ab/our%20team.png" width="250" height="200">
          <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-110"> </div>
             <p aligh="left" style="color:	#BDB76B;"><b>OUR TEAM  </b> <br></p>
                 
        <p aligh="left"> Amazing desserts. Amazing people. That's what Wish A Sprinkle is all about. We look for people who share our passion for producing the highest quality freshly baked desserts with exceptional customer service. Our team and their commitment to baking delicious products and providing gracious, attentive and knowledgeable service is what makes us great. As we grow, we are always looking for additional team members.</p></div><br>
        
        
        
        
    </main><br><br><br><br>
    <?php include("footer.php");?>
                
                
                
                
                
                
                  