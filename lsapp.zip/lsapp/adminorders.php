<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
     <link rel="icon" href="images/favicon.png">
    <title>Wish A Sprinkle</title>
    
    <!--Template based on URL below-->
    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/starter-template/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet">

    <!-- Place your stylesheet here-->
    <link href="/css/stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php include("adminnav.php");?><br><br><br>
    
     <div class="col-xl-12 col-lg-12  p-3 h-3 mt-1 text-light rounded-lg">
          <br><br><h3 style="font-family: 'Cookie', cursive; color:#FF7F50;"><b>Orders Details</b></h3><br>
                
                <table class="table table-bordered ">
                    <tr ><thead class="thead-dark">
                        <th colspan="9" style="color:#DCDCDC;font-family: 'Open Sans Condensed', sans-serif; ">Orders</th>
                    </thead> </tr>
                    <tr><th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>ID</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><u><center>Name</center></u></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Card No</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Product Name</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Amount</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Product Quantity</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Date</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Product ID</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Delete</u></center></th>
                    </tr>  
                   
                    
                      <?php
                    
                      
                     include("dbConnection.php");
    
              
                            $order="SELECT * FROM orders ";
                            if($order=mysqli_query($db,$order)){
                                 while ($row=mysqli_fetch_array($order))
                               {
                                     
                                     $OName =$row["Name"];
                                     $OCardno =$row["CardNumber"];
                                     $OPNAme =$row["ProductName"];
                                     $Amount = $row["Amount"];
                                     $PQty = $row["ProductQty"];
                                     $ODate =$row["Date"];
                                      $OPID = $row["ProductID"];
                                     $OID =$row["ID"];
                                     
                                 
    ?>
                    <tr>
                        </tr>
                  
                    <tr>  
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $OID;?></center></th>
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $OName;?></center></th>
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $OCardno;?></center></th>
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $OPNAme;?></center></th> 
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $Amount;?></center></th>
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $PQty;?></center></th>
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $ODate;?></center></th>
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $OPID;?></center></th> 
                        <th scope="col"> <a href=del.php?id=<?php echo $OID;?>><center><button type="button" class="btn btn-outline-danger">Delete</button></center></a></th>
                                        
                                           
                                            
                                            

                                         

                                        </tr>
   
                    <?php }}?>
                     </table><br><br><br><br><br><br><br><br><br><br><br>
          
             <?php include("footer.php");?>
                    
                
                      