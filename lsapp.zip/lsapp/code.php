<?php 
if(isset($_POST['updatebtn']))
{
    $id=$_POST["id"];
    $PName =$_POST["epnm"];
    $PPrice =$_POST["epprice"];
    $Pqty =$_POST["epqty"];
    $PImage = $_POST["epimage"];
    $PCategory = $_POST["epcategory"];
    $PDesc =$_POST["epdesc"];
    
    
    $query= "UPDATE product SET product_name='$PName',product_price='$PPrice',product_qty='$Pqty',product_image='$PImage',product_category='$PCategory',product_desc='$PDesc' WHERE id='$id'"
                                 
    
}






?>