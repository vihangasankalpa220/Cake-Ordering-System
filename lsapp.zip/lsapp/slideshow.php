<link href="https://fonts.googleapis.com/css?family=Charm|Cookie|Great+Vibes|Handlee|Italianno|Leckerli+One|Lobster|Niconne|Roboto|Scheherazade" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Cookie|Great+Vibes|Handlee|Italianno|Leckerli+One|Lobster|Niconne|Roboto|Scheherazade|Sue+Ellen+Francisco" rel="stylesheet">

<div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/img/slider/rose-2559897_960_720.jpg" alt="First slide">
        <div class="container">
          <div class="carousel-caption">
            <br>
            <br>
              <p ><h3 align="left" style="font-family: 'Sue Ellen Francisco', cursive;" >CAKES ARE SPECIAL.....</h3></p>
            <p ><h3 align="left" style="color: #FFB6C1; font-family: 'Sue Ellen Francisco', cursive;"  >WE  PROMISE  TO  LEAVE  YOU  SATISFIED  WITH  EVERY    BITE......</h3></p>
            <p ><h3 align="left" style="font-family: 'Sue Ellen Francisco', cursive;">EVERY  CELEBRATION  ENDS  WITH   SOMETHING SWEET,  A  CAKE, </h3></p>
            <p ><h3 align="left" style="color: #FFB6C1; font-family: 'Sue Ellen Francisco', cursive;" >AND  PEOPLE  REMEMBER,  IT'S  ALL  ABOUT  THE MEMORIES......</h3></p>
              
          </div>
        </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/img/slider/cake-1283824_960_720.jpg" alt="Second slide">
        <div class="container">
          <div class="carousel-caption">
           
              <p> <h4 align="left" style="color: 	#000000; font-family: 'Sue Ellen Francisco', cursive;"> <b>IN THE RIGHT HANDS, GREAT INGREDIENTS CAN BECOME SOMETHING AMAZING..<br><br></b><h4 align="left" style="font-family: 'Sue Ellen Francisco', cursive;"> <b>SOMETHING DELICIOUS, SOMETHING INDUIGENT, SOMETHING UNFORGETTABLE.</b></h4><br> <h4 align="left" style="color: #000000; font-family: 'Sue Ellen Francisco', cursive; "> <b>WHICH ARE EXACTLY THE KIND OF SOMETHINGS WE MAKE FRESH.. </b></h4><br><h4 align="left" style="font-family: 'Sue Ellen Francisco', cursive;"> <b>EVERYDAY..... </b></h4></h4></p>
        </div>
    </div>
      </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/img/slider/dessert-3321230_960_7204.jpg" alt="Third slide">
        <div class="container">
          <div class="carousel-caption">
        
              <p><h4 align="left" style="font-family: 'Sue Ellen Francisco', cursive; color:	#FF8C00;"><b>LIFE IS MADE OUT OF MOMENTS MINUTE TO MINUTE.</b></h4>
              <br><h4 align="left" style="color: #000000; font-family: 'Sue Ellen Francisco', cursive;"><b>OUR RITUALS CAN MAKE OR BREAK THE REST OF THE DAY....</b></h4>
              <br><h4 align="left" style="color:	#FF8C00; font-family: 'Sue Ellen Francisco', cursive; " ><b>SAVOURING FRASH BAKED CAKE AND FANTASTIC COFFEEIS A DFINITE </b>
              <br><br><h4 align="left" style="color: #000000; font-family: 'Sue Ellen Francisco', cursive;"><b>VICTORY OVER THE REST OF THE DAY...</b></h4></h4></p>
            </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>