<?php

   /* include("dbConnection.php");
        
            $sql="SELECT *  FROM product WHERE product_category = 'Birthdy_Cakes'";
            if($result=mysqli_query($db,$sql)){
                 while ($row=mysqli_fetch_array($result))
               {
               
               }
            }
                  
         */       

?>

<link href="https://fonts.googleapis.com/css?family=Cookie|Great+Vibes|Handlee|Italianno|Leckerli+One|Lobster|Roboto" rel="stylesheet">


<div class="row">
    <div class="col-xl-12 col-lg-12 p-4  ">
            <div class="card-deck">
          <div class="card">
            <img class="card-img-top" src="images/img/1233.jpg" alt="Card image cap" width="50" height="375">
            <div class="card-body">
                <h2 style="font-family: 'Italianno', cursive; color: #008080;"   class="card-title" ><center><b>Cakes</b></center></h2>
                  <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
              <p  class="card-text">Cake is a form of sweet dessert that is typically baked. In their oldest forms, cakes were modifications of breads,and that share features with other desserts such as pastries, meringues, custards, and pies.</p>
                <p class="card-text"><small class="text-muted"><a href="BirthdayCakes.php"><center><button type="button" class="btn btn-primary">CAKES</button></center></a></small></p>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="images/img/cuprose.jpg" alt="Card image cap" width="50" height="375">
            <div class="card-body">
                <h2 style="font-family: 'Italianno', cursive; color: #008080;"   class="card-title"><center> <b>Cup cakes</b></center></h2>
                <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
              <p class="card-text">A cupcake is a small cake designed to serve one person, which may be baked in a small thin paper cup. As with larger cakes, icing and other cake decorations such as fruit and candy may be applied.</p>
                <p class="card-text"><small class="text-muted"><a href ="cupcakes.php"><center><button type="button" class="btn btn-primary"> CUPCAKES</button></center></a></small></p>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="images/img/macroonn1.jpg" alt="Card image cap" width="50" height="375">
            <div class="card-body">
                <h2 style="font-family: 'Italianno', cursive; color: #008080;"   class="card-title"><center><b>Macroons</b></center></h2>
                <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
              <p class="card-text">A macaroon is a small cookies, typically made from ground almonds, with sugar and sometimes flavorings, and/or a chocolate coating.Some recipes call for sweetened condensed milk.</p>
                <p class="card-text"><small class="text-muted"><a href="macroon.php"><center><button type="button" class="btn btn-primary">MACROONS</button></center></a></small></p>
            </div>
          </div>
                
                
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-12 col-lg-12 p-4 ">
            <div class="card-deck">
          <div class="card">
            <img class="card-img-top" src="images/img/brwn.jpg" alt="Card image cap" width="50" height="375">
            <div class="card-body">
                <h2 style="font-family: 'Italianno', cursive; color: #008080;"   class="card-title"><center><b>Brownies</b></center></h2>
                 <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
              <p class="card-text">A chocolate brownie (commonly referred to as simply brownie) is a square, baked, chocolate dessert. Brownies come in a variety of forms and may be either fudgy or cakey, depending on their density.</p>
                <p class="card-text"><small class="text-muted"><a href="brownies.php"><center><button type="button" class="btn btn-primary">BROWNIES</button></center></a></small></p>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="images/img/bluecookie.jpg" alt="Card image cap" width="50" height="375">
            <div class="card-body">
                <h2 style="font-family: 'Italianno', cursive; color: #008080;"   class="card-title"><center><b>Cookies</b></center></h2>
                <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
              <p class="card-text">A cookie is a baked or cooked food that is small, flat and sweet. It usually contains flour, sugar and some type of oil or fat. It may include other ingredients such as raisins, oats, chocolate chips, nuts, etc.</p>
                <p class="card-text"><small class="text-muted"><a href="cookies.php"><center><button type="button" class="btn btn-primary">COOKIES</button></center></a></small></p>
            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src="images/img/pie.jpg" alt="Card image cap" width="50" height="375">
            <div class="card-body">
                <h2 style="font-family: 'Italianno', cursive; color: #008080;"   class="card-title"><center><b>Pie</b></center></h2>
                   <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
              <p class="card-text">A pie is a baked dish which is usually made of a pastry dough casing that covers or completely contains a filling of various sweet or savoury ingredients which is unconditionally sweet and taste.</p>
                <p class="card-text"><small class="text-muted"><a href="pie.php"><center><button type="button" class="btn btn-primary text-center">PIE</button></center></a></small></p>
            </div>
          </div>
        </div>
    </div>
</div>

<?php
 

?>