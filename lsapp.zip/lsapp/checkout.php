<?php
  session_start();
   
   include("dbConnection.php");

  $Mem = $_SESSION["Email"] ;


                               



   
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/favicon.png">
    <title>Wish A Sprinkle</title>
    
    <!--Template based on URL below-->
    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/starter-template/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- Place your stylesheet here-->
    <link href="/css/stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>

<?php include("loginnav.php");?>
    
  
     

    <main role="main" class="container"><br><br><br><br>
        
        <div class="row">
            <div class="col-xl-12 col-lg-12 shadow p-3 h-3 text-dark rounded-lg">Check Out :  </div>
            <div class="col-xl-12 col-lg-12 p-3 h-3 text-dark rounded-lg">
                <div class="row">
                    <div class="col-xl-6 col-lg-6  "> </div>
                    <div class="col-xl-6 col-lg-6  ">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6  text-right ">Customer Name</div>
                            <div class="col-xl-6 col-lg-6  text-center " ><?php echo $Mem; ?></div>
                        
                        </div>
                    
                    </div>
                </div><div class="row">
                    <div class="col-xl-6 col-lg-6  "> </div>
                    <div class="col-xl-6 col-lg-6  ">
                        <div class="row">
                        
                            <div class="col-xl-6 col-lg-6  text-right ">Total Amount</div>
                            <div class="col-xl-6 col-lg-6  text-center " >
                            
                                   <?php
                                 $Mem = $_SESSION["Email"] ;
                                 $SessionMail=$Mem;
                                $sqlsum = "SELECT SUM(Price*Qty) AS Total FROM cart where User='".$SessionMail."'  ";
                                if($result=mysqli_query($db,$sqlsum)){
                                     while ($row=mysqli_fetch_array($result))
                                   {
                                         echo $row['Total'];
                                          
                                         
                                     }
                                }
                            
                            ?>
                            
                            </div>
                            
                            <?php?>
                        
                        </div>
                    
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-lg-6  "> </div>
                    <div class="col-xl-6 col-lg-6  ">
                        <div class="row">
                            <?php $date=date("Fj,Y");?>
                            <div class="col-xl-6 col-lg-6 text-right ">Date</div>
                            <div class="col-xl-6 col-lg-6 text-center " ><?php echo $date;   $ab = $_SESSION["CheckCartID"] ; echo $ab;?></div>
                        
                        </div>
                    
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-lg-6  "> </div>
                    <div class="col-xl-6 col-lg-6  ">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6  "></div>
                            <div class="col-xl-6 col-lg-6 " >
                                <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#pay"> Purchase </button>
                            </div>
                            
                            
  

                                  <!-- The Modal -->
                                  <div class="modal" id="pay">
                                    <div class="modal-dialog">
                                      <div class="modal-content">

                                        <!-- Modal Header -->
                                        <div class="modal-header">
                                          <h4 class="modal-title">Payment System</h4>
                                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>

                                        <!-- Modal body -->
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-12 col-md-12 text-center col-lg-12 col-xl-12   m-1 ">
                                                     <a type="button" class="btn  btn-block" data-toggle="modal" data-target="#visa"> <img src="images/payment/visa.png" width="70%"> </a>
                                                </div>
                                                <div class="col-xs-12 col-sm-12 col-md-12 text-center col-lg-12 col-xl-12   m-1 ">
                                                    <a href="https://www.paypal.com/us/signin" type="button" class="btn  btn-block"  ><img src="images/payment/paypal.png" width="70%"></a>
                                                </div>
                                                


                                            </div>
                                        </div>

                                        <!-- Modal footer -->
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        </div>

                                      </div>
                                    </div>
                                  </div>
                            
                            
                             <div class="modal" id="visa">
                                    <div class="modal-dialog">
                                      <div class="modal-content">

                                        <!-- Modal Header -->
                                        <div class="modal-header">
                                          <h4 class="modal-title">Debit Card Payment</h4>
                                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>

                                        <!-- Modal body -->
                                          <form method="post" action="checkout.php">
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-12 col-md-12 text-center col-lg-12 col-xl-12   m-1 ">
                                                     <div class="form-group">
                                                        <label for="exampleInputEmail1">Card Number</label>
                                                        <input type="text" class="form-control" name="CardNumber" maxlength="16"  placeholder="xxxx xxxx xxxx xxxx">

                                                      </div>
                                                    <label for="exampleInputEmail1">Expired Date</label>
                                                    <div class="form-group">
                                                        
                                                        <input type="text" class="form-control col-md-2 col-sm-2 col-lg-2" maxlength="2" name="DD"  placeholder="DD" style="float:left;">
                                                        <input type="text" class="form-control  col-md-2 col-sm-2 col-lg-2" maxlength="2"  name="MM"  placeholder="MM"  style="float:left;">
                                                        <input type="text" class="form-control  col-md-6 col-sm-6 col-lg-6" maxlength="4"  name="YYYY"  placeholder="YYYY"  style="float:left;">
                                                        

                                                      </div>
                                                    
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">CVS</label>
                                                        <input type="text" class="form-control" name="CVS" maxlength="3"   placeholder="xxx">

                                                      </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-12 col-md-12 text-center col-lg-12 col-xl-12   m-1 ">
                                                     <input type="submit" class="btn btn-info" name="PurchaseBtn" value="Purchase">
                                                </div>
                                               
                                                


                                            </div>
                                        </div>
 </form>
                                        

                                      </div>
                                    </div>
                                  </div>
                            
                            
                            <?php
                            
                             $sqlcart="SELECT * FROM cart  where User='".$SessionMail."'";
                            if($resultcart=mysqli_query($db,$sqlcart)){
                                 while ($rowcart=mysqli_fetch_array($resultcart))
                               {
                                     
                                     $rowid =$rowcart["ID"];
                                      $rowpname=$rowcart["Name"];
                                      $rowpqty=$rowcart["Qty"];
                                      $rowpprice=$rowcart["Price"];

                                   $_SESSION['CheckCartID']=$rowid;
                                   $_SESSION['CheckCartName']=$rowpname;
                                   $_SESSION['CheckCartQty']=$rowpqty;
                                   $_SESSION['CheckCartPrice']=$rowpprice;
                                     
                                     $CCID = $_SESSION["CheckCartID"] ;
                                  $CCName = $_SESSION["CheckCartName"] ;
                             $CCQty = $_SESSION["CheckCartQty"] ;
                             $CCPrice = $_SESSION["CheckCartPrice"] ;
                                     
                                      if(isset ($_POST['PurchaseBtn'])){
                                        $CardNumber=$_POST['CardNumber']; 
                                        
                                          $Mem = $_SESSION["Email"] ;
                                          $SessionMail=$Mem;


                                        $sql="insert into orders (Name, CardNumber,ProductID,ProductName,ProductQty,Amount,Date) value ('$SessionMail','$CardNumber','$CCID','$CCName','$CCQty','$CCPrice','$date')";
                                        mysqli_query($db,$sql) ;



                                    }
                                     
                                   
                                 }
                                
                                 
                            
                            }
                                   
                          


                                   
            
                
                ?>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        
                        </div>
                    
                    </div>
                </div>
            
            </div>
            <div class="col-xl-12 col-lg-12  p-3 h-3 mt-1 text-light rounded-lg">
                
                <table class="table table-bordered ">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Product Name</th>
                      <th scope="col">Product Qty</th>
                      <th scope="col">Product Price</th>
                       
                      <th scope="col">Remove</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                        <?php
                         
                        if(!isset($_SESSION["Email"])){
                            echo 'You have to login to add items in your cart <a href="login.php">Click To Login</a> ';
                            }
                      else{
                            include("dbconnection.php");

                  
                       $Mem = $_SESSION["Email"] ;
                          $SessionMail=$Mem;
                          
                          echo  $SessionMail;
                       
                     
                     $sqlcart="SELECT * FROM cart  where User='".$SessionMail."'";
                            if($resultcart=mysqli_query($db,$sqlcart)){
                                 while ($rowcart=mysqli_fetch_array($resultcart))
                               {
                                     
                                     $rowid =$row["ID"];
                                      $rowpname=$row["Name"];
                                      $rowpqty=$row["Qty"];
                                      $rowpprice=$row["Price"];

                                   $_SESSION['CheckCartID']=$rowid;
                                   $_SESSION['CheckCartName']=$rowpname;
                                   $_SESSION['CheckCartQty']=$rowpqty;
                                   $_SESSION['CheckCartPrice']=$rowpprice;
                                            
                     
                     
                     ?>
                    <tr>
                      <th scope="row"><?php  echo $rowcart["ID"].' '; ?></th>
                      <td><?php  echo $rowcart["Name"].' ';?></td>
                      <td><input type="number" class="form-control  " min="1" id="inputAddress2" value="<?php  echo $rowcart["Qty"];?>"></td>
                      <td>Rs. <?php  echo $rowcart["Price"].' ';?></td> 
                        
                     
                        <td><a href="removedata.php?id=<?php echo $rowcart["ID"]?>" ><center> <button type="button" class="btn btn-danger" data-dismiss="modal">Remove</button></center></a></td>
                    </tr>
                      
                       <?php   } 
                            
                           
                            
                            }}?>
                    
                  </tbody>
                </table>
                <div class="row">
                    <div class="col-xl-12 col-lg-12  text-right">  </div>
                </div>
               
            
            
            </div>
        
        </div>
       

    </main><!-- /.container -->

<br><br><br><br><br><br>
    
    
    
     <?php include("footer.php");?>
     
    
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>
</html>