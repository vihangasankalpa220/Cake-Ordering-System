<?php 
 $link = mysqli_connect("localhost","root","");
mysqli_select_db($link,"lsapp");
$id=$_GET["id"];
$res= mysqli_query($link,"select * from product where id=$id");
while($row = mysqli_fetch_array($res))
{
    $product_name = $row["product_name"];
    $product_price = $row["product_price"];
    $product_qty = $row["product_qty"];
    $product_img = $row["product_image"];
    $product_cat = $row["product_category"];
    $product_desc = $row["product_desc"];
    
}


?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
     <link rel="icon" href="images/favicon.png">
    <title>Wish A Sprinkle</title>
    
    <!--Template based on URL below-->
    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/starter-template/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- Place your stylesheet here-->
    <link href="/css/stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php include("adminnav.php");?><br><br><br>
    
    <main role="main" class="container">
        <div class="row">
            <div class="col-xl-4   p-1  "></div>
            <div class="col-xl-5  p-1 mt-5  ">
                
                <?php
                     include("dbConnection.php");?>
                <h3 style="font-family: 'Cookie', cursive; color:#FF7F50;"> <b>Update Product</b></h3><br>
                <form name="form1" action="" method="post" enctype="multipart/form-data">  
                    <table>
                        <tr>
                            <td colspan="2" align="center"></td>
                            <img src="<?php echo $product_img; ?>" width="150" height="150" align="center">
                        </tr>
                    </table>
                    <div class="form-group"><br>
                    <label for="formGroupExampleInput" >Product Name</label>
                    <input type="text" class="form-control" name="pnm" value="<?php echo $product_name; ?>" id="formGroupExampleInput" placeholder="">
                  </div>
                  <div class="form-group">
                    <label for="formGroupExampleInput2" >Product Price</label>
                    <input type="text" class="form-control"  name="pprice" value="<?php echo $product_price; ?>" id="formGroupExampleInput2" placeholder="">
                  </div>
                   <div class="form-group">
                    <label for="formGroupExampleInput3" >Product Quantity</label>
                    <input type="text" class="form-control" name="pqty" value="<?php echo $product_qty; ?>" id="formGroupExampleInput3" placeholder="">
                  </div>
                     <div class="form-group">
                    <label for="exampleFormControlFile1" >Product Image</label>
                    <input type="file" class="form-control-file" name="pimage" id="exampleFormControlFile1">
                  </div>
                      <div class="form-group">
                    <label for="exampleFormControlSelect1">Product Category</label>
                   
                          <select class="form-control" name="pcategory" id="exampleFormControlSelect1">
                      <option value="Birthdy_Cakes">Birthday Cakes</option>
                      <option value="Seasonal_Greeting_Cakes">Seasonal Greeting Cakes</option>
                      <option value="Thank_you_Cakes">Thank You Cakes</option>
                      <option value="Anniversay_Cakes">Anniversay Cakes</option>
                      <option value="Get_well_Soon_Cakes">Get Well Soon Cakes</option>
                        <option value="Sorry_Cakes">Sorry Cakes</option>
                      <option value="Love_Cakes">Love Cakes</option>
                      <option value="Congratulation_Cakes">Congragulation Cakes</option>
                        <option value="Thinking_of_you_Cakes">Thinking of You Cakes</option>
                      <option value="Best_Wishes_Cakes">Best Wishes Cakes</option>
                      <option value="Sympathy_Cakes">Sympathy Cakes</option>
                        <option value="Cupcakes">Cupcakes</option>
                      <option value="Macroons">Macroons</option>
                      <option value="Cookies">Cookies</option>
                        <option value="Brownies">Brownies</option>
                        <option value="Pie">Pie</option>
                    </select>
                    
                  </div>
                      <div class="form-group">
                    <label for="exampleFormControlTextarea1" >Product Description</label>
                    <textarea class="form-control"  name="pdesc" id="exampleFormControlTextarea1" rows="4"><?php echo $product_desc; ?></textarea>
                  </div>
                    <input type="submit" value="Update"    class="btn btn-primary" name="UpdateBtn">
                    
                </form></div></div></main>
    
    <?php
    if(isset($_POST["UpdateBtn"]))
    {
        $fnm = $_FILES["pimage"]["name"];
        
        if($fnm=="")
        {
            mysqli_query($link,"update product set product_name ='$_POST[pnm]', product_price ='$_POST[pprice]', product_qty ='$_POST[pqty]', product_category ='$_POST[pcategory]', product_desc ='$_POST[pdesc]' where id=$id");
                
        }
        else
        {
                        $v1=rand(1111,9999);
                        $v2=rand(1111,9999);
                        
                        $v3= $v1.$v2;
                        $v3= md5($v3);
                        
                        $fnm= $_FILES["pimage"]["name"];
                        $dst="./product_image/".$v3.$fnm;
                        $dst1="product_image/".$v3.$fnm;
                        
                        move_uploaded_file($_FILES["pimage"]["tmp_name"],$dst);
            
                        mysqli_query($link,"update product set product_image ='$dst1', product_name ='$_POST[pnm]', product_price ='$_POST[pprice]', product_qty ='$_POST[pqty]', product_category ='$_POST[pcategory]', product_desc ='$_POST[pdesc]' where id=$id");
            
        }
    }
    
    
    
    
    ?>
    


                                      
<?php include("footer.php");?>