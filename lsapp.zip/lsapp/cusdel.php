<?php
$link = mysqli_connect("localhost","root","");
mysqli_select_db($link,"lsapp");
$id=$_GET["id"];
mysqli_query($link,"delete from acc where ID=$id");
 header("location:customerreg.php");
?>