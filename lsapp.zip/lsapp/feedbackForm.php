        <?php
                       session_start();
 $Mem = $_SESSION["Email"] ;
     if(isset ($_POST['FeedbackBtn'])){
                            $feedback=$_POST['feedback'];
                            $sqlfeeedback="insert into feedback (FeedBack, User, ProductID) value ('$feedback','$Mem','$PID')";
                            mysqli_query($db,$sqlfeeedback) ;
                        }
 

                       
                
                ?>

    <div class="row">
            <div class="col-xl-6 col-lg-6 bg-danger">
                aa
            </div> 
            <div class="col-xl-6 col-lg-6 bg-info">
                <div class="col-xl-6 col-lg-6   mt-2 pt-2 pb-2 pl-5 pr-5 "> <?php echo $Mem;?></div>
                <form method="post" action="productsDetails.php">
                    
                   <textarea class="form-control" name="feedback" id="exampleFormControlTextarea1" rows="5"></textarea>  <br>
                   <input type="submit" class="btn btn-primary" value="Write your feedback" name="FeedbackBtn">
                    
                </form>
            </div>
        </div>
        
