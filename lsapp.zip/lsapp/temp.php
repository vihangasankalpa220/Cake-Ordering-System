 

<?php
                     session_start();
                      include("dbconnection.php");
                      $Mem = $_SESSION["Email"] ;
                    $test=$Mem;
                        echo $Mem;  
                   
                    $sqlcart="SELECT * FROM cart  where User='".$test."'";
                            if($resultcart=mysqli_query($db,$sqlcart)){
                                 while ($rowcart=mysqli_fetch_array($resultcart))
                               {
                                     echo $rowcart["User"].'<br> ';
                                     echo $rowcart["Name"].'<br> ';
                                     echo $rowcart["Qty"].'<br> ';
                                     echo $rowcart["Price"].'<br>';

                                 }
                            }
                     
                     
                     ?>