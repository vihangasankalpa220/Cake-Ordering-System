   



<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
     <link rel="icon" href="images/favicon.png">
    <title>Wish A Sprinkle</title>
    
    <!--Template based on URL below-->
    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/starter-template/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    
    
    
    
    <!-- Place your stylesheet here-->
    <link href="/css/stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php include("adminnav.php");?><br><br><br>
    
    
    
    <main role="main" class="container">
        <div class="row">
            <div class="col-xl-4   p-1  "></div>
            <div class="col-xl-5  p-1 mt-5  ">
                
                <?php
                     include("dbConnection.php");?>
                <h3 style="font-family: 'Cookie', cursive; color:#FF7F50;"> <b>Add Product</b></h3><br>
                
                
           <?php      
                include("dbConnection.php");
                if(isset($_POST['uploadbtn']))
                {
                    $id = $_POST['eid'];

                    $query = "SELECT * FROM product WHERE id='$id'";
                    $query_run = mysqli_query($db,$query);
                

                    foreach($query_run as $row )
                    {

?>
        
                
                
                <form method="post" action="code.php" enctype="multipart/form-data">
                    <div class="form-group">
                    <label for="formGroupExampleInput" >Product Name</label>
                    <input type="text" class="form-control" name="eid" value="<?php echo $row["product_name"]?>" id="formGroupExampleInput" placeholder="">
                  </div>
                  <div class="form-group">
                    <label for="formGroupExampleInput" >Product Name</label>
                    <input type="text" class="form-control" name="epnm" value="<?php echo $row["product_name"]?>" id="formGroupExampleInput" placeholder="">
                  </div>
                  <div class="form-group">
                    <label for="formGroupExampleInput2" >Product Price</label>
                    <input type="text" class="form-control"  name="epprice" value="<?php echo $row["product_price"]?>" id="formGroupExampleInput2" placeholder="">
                  </div>
                   <div class="form-group">
                    <label for="formGroupExampleInput3" >Product Quantity</label>
                    <input type="text" class="form-control" name="epqty" value="<?php echo $row["product_qty"]?>" id="formGroupExampleInput3" placeholder="">
                  </div>
                     <div class="form-group">
                    <label for="exampleFormControlFile1" >Product Image</label>
                    <input type="file" class="form-control-file" name="epimage" value="<?php echo $row["product_image"]?>" id="exampleFormControlFile1">
                  </div>
                      <div class="form-group">
                    <label for="exampleFormControlSelect1">Product Category</label>
                    <select class="form-control" name="epcategory" value="<?php echo $row["product_category"]?>"  id="exampleFormControlSelect1">
                      <option value="Birthdy_Cakes">Birthday Cakes</option>
                      <option value="Seasonal_Greeting_Cakes">Seasonal Greeting Cakes</option>
                      <option value="Thank_you_Cakes">Thank You Cakes</option>
                      <option value="Anniversay_Cakes">Anniversay Cakes</option>
                      <option value="Get_well_Soon_Cakes">Get Well Soon Cakes</option>
                        <option value="Sorry_Cakes">Sorry Cakes</option>
                      <option value="Love_Cakes">Love Cakes</option>
                      <option value="Congratulation_Cakes">Congragulation Cakes</option>
                        <option value="Thinking_of_you_Cakes">Thinking of You Cakes</option>
                      <option value="Best_Wishes_Cakes">Best Wishes Cakes</option>
                      <option value="Sympathy_Cakes">Sympathy Cakes</option>
                        <option value="Cupcakes">Cupcakes</option>
                      <option value="Macroons">Macroons</option>
                      <option value="Cookies">Cookies</option>
                        <option value="Brownies">Brownies</option>
                        <option value="Pie">Pie</option>
                    </select>
                  </div>
                      <div class="form-group">
                    <label for="exampleFormControlTextarea1" >Product Description</label>
                    <textarea class="form-control"  name="epdesc" value="<?php echo $row["product_desc"]?>"  id="exampleFormControlTextarea1" rows="3"></textarea>
                  </div>
                   
                    <button type="submit" name="updatebtn" class="btn btn-primary">Update</button>
                    
                    
                      </form> </div>
            
            <div class="col-xl-3   p-1 text-center"></div>
            
        </div>
          </main>
    
    
     <?php include("footer.php");?>