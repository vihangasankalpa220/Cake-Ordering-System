-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2019 at 05:04 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lsapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc`
--

CREATE TABLE IF NOT EXISTS `acc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `acc`
--

INSERT INTO `acc` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '123'),
(2, 'naadiya@gmail.com', '321'),
(3, 'raza@gmail.com', '123'),
(4, 'abc@gmail.com', '567'),
(7, 'okm', 'ko'),
(12, 'naadiyarizvi1021996@gmail.com', '123'),
(10, 'naadiyarizvi1021996@gmail.com', '123'),
(11, 'naadiyarizvi1021996@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `adminacc`
--

CREATE TABLE IF NOT EXISTS `adminacc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `adminacc`
--

INSERT INTO `adminacc` (`id`, `email`, `password`) VALUES
(1, 'naadiya@gmail.com', '123'),
(8, 'naadiyarizvi1021996@gmail.com', '456');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `User` varchar(255) NOT NULL,
  `Price` int(11) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Qty` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`ID`, `User`, `Price`, `Image`, `Name`, `Qty`) VALUES
(35, 'raza@gmail.com', 1200, '', 'Rasberry Chocolate Cake', 2),
(50, 'raza@gmail.com', 800, '', 'Pink Butter Cake', 3),
(49, 'naadiya@gmail.com', 250, '', 'Apple Rose Pie', 5),
(69, 'naadiya@gmail.com', 1200, '', 'Hazelnut Cheesecake', 2),
(70, 'naadiya@gmail.com', 800, '', 'Pink Butter Cake', 3),
(68, 'naadiya@gmail.com', 1500, '', 'Vanilla Bean Cake', 3);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `query` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `user`, `email`, `query`) VALUES
(10, 'naadiya', 'naadiyarizvi1021996@gmail.com', 'hi');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `User` varchar(255) NOT NULL,
  `ProductID` varchar(255) NOT NULL,
  `FeedBack` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`ID`, `User`, `ProductID`, `FeedBack`) VALUES
(22, 'naadiya@gmail.com', '107', 'Can i get more details of the product.');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `CardNumber` varchar(255) NOT NULL,
  `ProductName` varchar(255) NOT NULL,
  `Amount` varchar(255) NOT NULL,
  `ProductQty` varchar(255) NOT NULL,
  `Date` varchar(255) NOT NULL,
  `ProductID` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ID`, `Name`, `CardNumber`, `ProductName`, `Amount`, `ProductQty`, `Date`, `ProductID`) VALUES
(10, 'naadiya@gmail.com', '1234567887654321', 'Rasberry Chocolate Cake', '1200', '2', 'April10,2019', '46'),
(11, 'naadiya@gmail.com', '4562456623235656', 'Blue Velvet Cake', '900', '1', 'April10,2019', '45'),
(9, 'naadiya@gmail.com', '1234567887654321', 'Blue Velvet Cake', '900', '1', 'April10,2019', '45'),
(8, 'naadiya@gmail.com', '1234567887654321', 'Blue-berry Cake', '800', '1', 'April10,2019', '47'),
(12, 'naadiya@gmail.com', '4562456623235656', 'Rasberry Chocolate Cake', '1200', '2', 'April10,2019', '46');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `product_price` int(5) NOT NULL,
  `product_qty` int(5) NOT NULL,
  `product_image` varchar(500) NOT NULL,
  `product_category` varchar(255) NOT NULL,
  `product_desc` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=137 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_price`, `product_qty`, `product_image`, `product_category`, `product_desc`) VALUES
(5, 'Avacado Chocolate Cake', 900, 2, 'product_image/a811c85083c27a6cfd46ab787f45bbf3avacadoo.jpg', 'Birthdy_Cakes', 'avacado flavour'),
(6, 'Orange Cake', 900, 5, 'product_image/ecc56a6ce7fa1035c9aeb089ba0ecb76orange1.jpg', 'Seasonal_Greeting_Cakes', 'orange cake'),
(12, 'Pink Butter Cake', 800, 3, 'product_image/195fbf7459d01203bca9aafab758035fpink1.jpg', 'Birthdy_Cakes', 'for a pink Wish'),
(20, 'Lemon Sprinkle', 700, 1, 'product_image/a68abb4af023f9610885ced83003ac76lemon.jpg', 'Thank_you_Cakes', 'For thanking someone special'),
(37, 'Blue Velvet Cake', 900, 1, 'product_image/264428db3b8f9887425eca00f5f6213cblue_cake2.jpg', 'Birthdy_Cakes', 'birthday wishes'),
(23, 'Floral Swiss-Roll', 1000, 2, 'product_image/a088af774caebc22520aade93551262cdd.jpg', 'Sorry_Cakes', 'Details Serves 4 to 8 Four 4-inch mini cakes Warm chocolate ganache will flow freely from the center of these moist chocolate cakes when you slice into this unbelievable dessert. These sinful delights are gluten free, so they are the perfect cake for someone with a restricted diet. We include 4 cakes that can be warmed in the oven.'),
(32, 'Pumpkin Spice French Macroon', 90, 5, 'product_image/4742bc0815d7c931abbf9c85df432801maa.jpg', 'Macroons', 'made with real pumpkin extracts'),
(22, 'Cream Cake', 1200, 2, 'product_image/addc7d2e9f450e1efb1832cfb16580a7gg.jpg', 'Get_well_Soon_Cakes', 'get well soon'),
(21, 'Elegant Butter Cake', 1200, 1, 'product_image/06e83f485f995415dcbc296a48ab54d9c.jpg', 'Anniversay_Cakes', 'Details Serves 6 to 8 7 inches in diameter  Take your chocolate passion to the next level with the delectable flourless chocolate cake! We start with a thick and fudgy base, then add a layer of chocolate frosting and chocolate shavings all around the side.'),
(24, 'With Love', 900, 5, 'product_image/051c026a4c0cb07c7cfc6cc527038461jj.jpg', 'Love_Cakes', 'Details Serves 6 to 8 7 inches in diameter Take your chocolate passion to the next level with the delectable flourless chocolate cake! We start with a thick and fudgy base, then add a layer of chocolate frosting and chocolate shavings all around the side.'),
(26, 'Cream Congrats', 1200, 2, 'product_image/271112f5b9514a5730cf014e1848bb58aaa.jpg', 'Congratulation_Cakes', 'Details Serves 6 to 8 7 inches in diameter Two rich, chocolate cake layers are filled with luscious chocolate whipped cream mousse, then covered with milk chocolate frosting and a dark chocolate glaze. This best selling delight is then garnished with fudge rosettes and dark chocolate shaves.'),
(27, 'Green Thinking You', 700, 1, 'product_image/245cf1416628e152264f903cbcf11702cc.jpg', 'Thinking_of_you_Cakes', 'Details Serves 6 to 8 7 inches in diameter, Two rich, chocolate cake layers are filled with luscious chocolate whipped cream mousse, then covered with milk chocolate frosting and a dark chocolate glaze. This best selling delight is then garnished with fudge rosettes and dark chocolate shaves.'),
(28, 'Caramel Cake', 1200, 2, 'product_image/93147a2743e62d1c2075533c2e4e1ad8bbb.jpg', 'Best_Wishes_Cakes', 'Details Serves 6 to 8 7 inches in diameter, Creamy,dreamy caramel cake has finally arrived at Bake Me A Wish! Two delicious layers of chocolate cake are topped with a yummy mix of caramel frosting, drizzles of caramel - a light hint of salt - and finished with chocolate chips all around the sides.'),
(30, 'Strawberry Chamomile', 1500, 1, 'product_image/a408e1c3c3841836ebc27f419c53340faaa.jpg', 'Sympathy_Cakes', 'On worrying'),
(35, 'Apple Rose Pie', 250, 5, 'product_image/4447feddfeb08e50df5a60176ad181fdpa.JPG', 'Pie', 'apple pie'),
(40, 'Blue-berry Cake', 800, 1, 'product_image/3697392e3cbf85967ee6edb0d7963e31buleberry_cake.jpg', 'Birthdy_Cakes', 'blue berry cake'),
(39, 'Rasberry Chocolate Cake', 1200, 2, 'product_image/db27726740fe1d3e9451d0d597eef2a8rasbrry_cakee.jpg', 'Birthdy_Cakes', 'rasberry cake'),
(42, 'Rose Topped Butter Cake', 700, 2, 'product_image/06ddcc3db69731ef9e29abd5082e3245cakee2.jpg', 'Seasonal_Greeting_Cakes', 'rose cake'),
(43, 'Blue Velvet Cake', 900, 5, 'product_image/a9f18dcfcb37345978c46f29077a4dbeblue_cake2.jpg', 'Seasonal_Greeting_Cakes', 'velvet cake'),
(44, 'Yule Cake', 1200, 1, 'product_image/637256873f33f93d2fcd181602231532yule.jpg', 'Seasonal_Greeting_Cakes', 'yule cake'),
(49, 'Christmas Pieces', 900, 4, 'product_image/0c863b6a101085537689c7e2e6da14e9christ112.jpg', 'Seasonal_Greeting_Cakes', 'greetings'),
(50, 'Floral Wish', 1200, 2, 'product_image/f8523869ae904d7c6b8d89ecb9ea876bfloer1.jpg', 'Thank_you_Cakes', 'thanking '),
(58, ' Chocolate Rasberry Macroons', 150, 35, 'product_image/a0ed286506d4a6d6216d8e55baa6cd62mff.jpg', 'Macroons', 'white chocolate macroon'),
(66, 'Elegant Suprise', 1200, 2, 'product_image/23bd9a7f52504fc58f74f8bab30dfef3d.jpg', 'Birthdy_Cakes', 'for a special person'),
(64, 'Christmas Pieces', 700, 2, 'product_image/d707a3881cb261d73d5ba66ef87ebf49bb.jpg', 'Seasonal_Greeting_Cakes', 'fyg'),
(63, 'Simple Cream Cake', 1200, 3, 'product_image/a9949715d3b967a6b5e0aa2f88e6556dff.jpg', 'Congratulation_Cakes', 'Details Serves 6 to 8 7 inches in diameter Two layers of coffee washed cake are filled with the traditional mascarpone custard and topped with a light and delectable coffee whipped cream. As an extra touch, this delight is then sprinkled with dark chocolate and cocoa and adorned with a chocolate occasion plaque.'),
(110, 'JUMBO Springtime Cupcakes', 700, 3, 'product_image/a239cbaa222e6e7e39a0624dbd258e87m.jpg', 'Cupcakes', 'Serves 4 to 8; includes 4 JUMBO cupcakes                              These delicious Chocolate, Vanilla and Strawberry frosted cupcakes come together in perfect harmony with an elegant sugar flower placed on top. Includes a greeting card you can personalize online and arrives packaged in an elegant bakery gift box.'),
(107, 'Red Velvet Cupcakes', 150, 10, 'product_image/0520d9b554319ad83264dea9d1647771ee.jpg', 'Cupcakes', 'Details Serves 4 to 8; includes 4 JUMBO cupcakes. Delicious Red Velvet, Chocolate Crumb w/ filling, Confetti and Carrot come together in perfect harmony. Includes the greeting card of your choice and arrives packaged in an elegant bakery gift box.... sorry for all the shouting, we''re excited.'),
(98, 'Christmas Pieces', 900, 3, 'product_image/ddace98a35d27d5c02ee484450c13d08k.jpg', 'Thank_you_Cakes', 'sd'),
(111, 'Salted Caramel Chocolate Cake', 2000, 5, 'product_image/d7e00c8fc421abae92a6fd5a5fcf26bagg.jpg', 'Anniversay_Cakes', 'Details\r\nServes 6 to 8\r\n7 inches in diameter\r\nCreamy,dreamy caramel cake has finally arrived at Bake Me A Wish! Two delicious layers of chocolate cake are topped with a yummy mix of caramel frosting, drizzles of caramel - a light hint of salt - and finished with chocolate chips all around the sides.'),
(109, 'One Dozen Assorted Gourmet Cookies', 600, 3, 'product_image/57e442e07dd7c5ef7a181f0004508263g.jpg', 'Cookies', ' One dozen of our moist and delicious cookies in a variety of flavors - the sweetest treat around! Each gift includes 6 different types of cookies in an elegant gift box and arrives with your personalized greeting card. '),
(112, 'Vesuvius Cake', 1900, 4, 'product_image/2671c55b8d833c1abf45c3a6efc96726q.jpg', 'Anniversay_Cakes', 'Details\r\nServes 6 to 8\r\n6 inches in diameter\r\nIndulgence redefined with this Italian cake classic! We take a layer of chocolate cake, add a layer of cheesecake, smother the whole thing in chocolate and then, watch out, and eruption of mousse, ribbons of caramel & chocolate.\r\n'),
(113, 'Country Apple Pie', 500, 5, 'product_image/585c73ce96c7ca76176b603504f12cdcpinkrose.jpg', 'Pie', 'Details\r\nServes 6 to 8\r\nPie is 8 Inches Round\r\nApple Pie! We take a light a flaky crust and overfill the pan with as much apple, cinnamon and brown sugar as humanly possible, then bake it to perfection. Heat upon arrival for second and share it ala mode with your favorite ice cream for a true dessert sensation!'),
(114, 'Hazelnut Cheesecake', 1200, 2, 'product_image/11464fa1033ea005d33e2cb367b7a256cc.jpg', 'Get_well_Soon_Cakes', 'Details\r\nServes 6 to 8\r\n7 inches in diameter\r\n This sweet sensation is a layer of  cheesecake topped with hazelnut frosting, real hazelnuts drizzle! A gourmet treat the true cheesecake connoisseur'),
(115, 'Vanilla Bean Cake', 1500, 3, 'product_image/3ffb0cafd5cb234f762e5c9b160a2aa0d.jpg', 'Get_well_Soon_Cakes', 'Details\r\nServes 6 to 8\r\n7 inches in diameter\r\nEvery delightful bite contains an amazing blend of yellow cake, vanilla whipped cream mousse filling and a sweet buttercream frosting. On top of this two-layered cake is a decorative white chocolate and mousse garnish.'),
(116, 'Golden Fudge Celebration Cake', 1500, 3, 'product_image/80b599d35e4c70c41d0a4790e8990b2bi.jpg', 'Congratulation_Cakes', 'Details\r\nServes 6 to 8\r\nCake is 7 Inches Round\r\nCelebrate Life! with this gourmet twist on a traditional favorite. Our Golden Fudge Celebration cake is two moist & savory layers of yellow cake topped with a rich and creamy fudge frosting, celebration confetti sprinkles, and toasted-golden cake crumbs all around the side'),
(117, 'Boston Cream Cake', 1650, 2, 'product_image/d5523a46d940cba891fae8592cdadfc2a.jpg', 'Sorry_Cakes', 'Details\r\nCake is 7 Inches Round, Serves 6-8Two moist and light layers of golden cake are filled with traditional vanilla custard and topped with rich and delicious milk chocolate icing'),
(118, 'Blackout Cake', 1950, 4, 'product_image/09477d71bebd8fade45c47ed00fcf225g.jpg', 'Sorry_Cakes', 'Details\r\nServes 6 to 8\r\n7 inches in diameter\r\nTake the Blackout Chocolate Cake Challenge! This delicious chocolate creation includes layers of rich chocolate cake with fudge frosting in between topped with more chocolate crumbs piled on top!'),
(119, 'Heart Cake Collection', 1980, 1, 'product_image/52329457c7fa95d8da40c3f4f574bb17e.jpg', 'Love_Cakes', 'Details\r\nServes 6 to 8\r\n8 cake, \r\nShow your love for someone with the Heart Cake Collection.  The Heart Collection is a sweet selection of  delicious heart shaped cake confections that are sure to let that special someone that you are crazy about them!  Each heart is a moist and delicious sponge cake topped with a tantalizing glaze, candies.'),
(120, 'Red Velvet Brownie Cake', 1100, 3, 'product_image/182936e770086a2033244e517d35e8fbi.jpg', 'Love_Cakes', 'Details\r\nServes 6 to 8\r\n7 inches in diameter,\r\nThe Red Velvet Brownie Cake is a romantic and unique take on our traditional chocolate brownie cake. Rich, and marbled, red velvet brownie cake is covered by a sophisticated and delicious Napoleon-pastry-like icing and sprinkles all around the side.\r\n'),
(121, 'Cheesecake', 1200, 2, 'product_image/a2ad08900d30dd0b8e8a60dd56151711v.jpg', 'Thinking_of_you_Cakes', 'Details\r\nServes 6 to 8\r\n7 inches in diameter,\r\nCheesecake is made with a deliciously rich combination of cream cheese and Neufchatel cheese that will make taste buds rejoice. Underneath the thick layer of cheesecake is a soft, buttery graham cracker crust. Every mouth-watering bite is a truly divine experience that will keep recipients craving more.'),
(122, 'Chocolate Mousse Torte Cake', 1200, 2, 'product_image/45bd4cf7ca99c67951cf58c05b94d5ebaa.jpg', 'Thinking_of_you_Cakes', 'Details\r\nServes 6 to 8\r\n7 inches in diameter,\r\nTwo rich, chocolate cake layers are filled with luscious chocolate whipped cream mousse, then covered with milk chocolate frosting and a dark chocolate glaze. This best selling delight is then garnished with fudge rosettes and dark chocolate shaves.'),
(123, 'Cookies and Cream Brownie Cake', 900, 1, 'product_image/0615c4c86a3159c684730bed4d3a80efa.jpg', 'Best_Wishes_Cakes', 'Details Serves 6 to 8 7 inches in diameter, Chocolate lovers can''t wait to sink their teeth into our blissful Cookies and Cream Brownie Cake. The dense chocolate-fudge brownie cake is topped with crumbled Oreo® cookies and drizzled with creamy white and dark chocolate. '),
(124, 'German Chocolate Cake', 1200, 2, 'product_image/51c31a2ae2c075bf31d11d4c4789323bcc.jpg', 'Best_Wishes_Cakes', 'Details\r\nServes 6 to 8\r\n7 inches in diameter,\r\nThis delicious German Chocolate Cake is positively an American delight.Every bite contains a perfect mixture of rich chocolate cake, coconut, caramel and pecans for a truly satisfying experience.'),
(125, 'Vanilla Cake', 1900, 2, 'product_image/08984333644e09a966b8970fc505256cc.jpg', 'Sympathy_Cakes', 'Details\r\nServes 12 to 15,\r\nYummy in the Tummy! This wonderful vanilla cake measures 10" in diameter and is the perfect gift for the party. Two layers of moist yellow cake are topped with cream vanilla frosting - a fan favorite!'),
(126, 'Brownie Cheesecake Suprise', 1200, 2, 'product_image/2976201025e3bada00f2c422e54072abp.jpg', 'Sympathy_Cakes', 'Details\r\nServes 6 to 8\r\n7 inches in diameter,\r\nThe most spectacular chocolate cheesecake around! We start with a base of chocolate graham and creamy chocolate cheesecake - then we top this cake with a layer of fudge frosting, rich brownies and a drizzle of chocolate sauce! \r\n'),
(130, 'Springtime Flower Cookies', 900, 8, 'product_image/f7d87efa2834531fa949ecb895a6d893l.jpg', 'Cookies', 'Details\r\nServes 5 to 8 People,\r\nOur delicious butter cookies are cut and hand-decorated for the celebration of spring. Each gift includes 12 cookies made from all-natural ingredients.'),
(129, 'Blue Collection', 700, 8, 'product_image/c26661878a378f034c880d936ca80841m.jpg', 'Macroons', 'Details\r\nServes 4 to 6,\r\nThis delightful set of blue collection macroons are straight out of a fairy tale. '),
(131, 'One Dozen Assorted Gourmet Cookies', 1200, 12, 'product_image/c9f8e6efa2f30919b49716e59e7da1f6c.jpg', 'Cookies', 'Details\r\nServes 8 to 12 People,\r\nOne dozen of our moist and delicious cookies in a variety of flavors - the sweetest treat around! Each gift includes 6 different types of cookies in an elegant gift box and arrives with your personalized greeting card. We include Chocolate Chip, Oatmeal Raisin, Lemon Sugar, Ginger Molasses, Snickerdoodle and Almond Butter cookies that are simply out of this world'),
(132, 'Chocolate and Raspberry Tarts', 500, 2, 'product_image/c1ba006fb82d8e381d1f3e1afee331396c674012d5b83f1c011a1fca37a4fbb0.jpg', 'Pie', 'Details\r\nServes 6 to 8\r\n8 inches in diameter,\r\nAn exquisite indulgence to our delicious roster of pies! We start with a chocolate crust, then layer in dreamy chocolate mousse to the brim and finish with delicious chocolate shaves!'),
(133, 'Oreo Stuffed Mint Chocolate Brownies', 100, 18, 'product_image/ddbf2bc1b00c5a48c25e2d4226696771c5d38c9735b868870d38c800299ec0d7.jpg', 'Brownies', 'Details\r\nServes 14 to 18,\r\nSend this delicious combo gift and itâ€™ll be an instant crowd pleaser. Mouths will water over the array of goodies as recipients decide which dessert to try first. \r\n'),
(134, 'Red Velvet Oreo Truffled Brownie ', 150, 15, 'product_image/e74185a8f6ce224026108e815b7f777d56b09628f24dc053cbf09ce6bc18fce5.jpg', 'Brownies', 'Details Serves 14 to 18, \r\nSend this delicious combo gift and itâ€™ll be an instant crowd pleaser. Mouths will water over the array of goodies as recipients decide which dessert to try first.'),
(135, 'Oreo Cream Cheese Brownies', 175, 17, 'product_image/0507ca6ee5bbdb375773972c9ed9332fc7d38132de23a69a75d4e88191d01299.jpg', 'Brownies', 'Details Serves 14 to 18, \r\nSend this delicious combo gift and itâ€™ll be an instant crowd pleaser. Mouths will water over the array of goodies as recipients decide which dessert to try first.');
