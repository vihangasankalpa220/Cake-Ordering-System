<?php
   $db=mysqli_connect("localhost","root","","lsapp"); 
   session_start();
   
   $user_check = $_SESSION['login_user'];
   
   $ses_sql = mysqli_query($db,"select email from acc where Email = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['Email'];
   $login_session = $row['PDEmail'];


   $login_session = $row['Searchtxt'];


   $login_session = $row['CheckCartID'];
   $login_session = $row['CheckCartName'];
   $login_session = $row['CheckCartQty'];
   $login_session = $row['CheckCartPrice'];

                                  

   $login_session = $row['ProductID'];
   $login_session = $row['ProductName'];
   $login_session = $row['ProductPrice'];
   $login_session = $row[$cartUser];
   
   if(!isset($_SESSION['login_user'])){
      header("location:login.php");
   }

     

?>