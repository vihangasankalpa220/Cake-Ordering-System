<link href="https://fonts.googleapis.com/css?family=Cookie|Great+Vibes|Handlee|Italianno|Leckerli+One|Lobster|Niconne|Roboto|Scheherazade|Sue+Ellen+Francisco" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<div class="row mt-3 mb-3">
    <div class="col-xl-6 col-lg-6   ">
      <img src="images/common/ss.jpg">
    </div>
    <div class="col-xl-6 col-lg-6 bg-sucess text-center pt-5">
        <h1 style="font-family: 'Italianno', cursive; color:#DB7093;"><b>Sprinkle Cakes   </b></h1>
        <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
        <p align="left">Sprinkle cakes are super festive cakes that are decorated with sprinkles either on the outside only or on both the inside and the outside.</p>
        <a href="Thank_you.php"><button class="btn btn-primary  ">More Details</button></a>
    </div>
    
    
    <div class="col-xl-6 order-2 col-lg-6  ">
      <img src="images/img/macroon/ee.jpg">
    </div>
    <div class="col-xl-6 order-1 col-lg-6 bg-sucess text-center pt-5">
        <h1 style="font-family: 'Italianno', cursive; color:#DB7093;"><b>Sprinkle Macroons   </b></h1>
        <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
        <p align="left">A macaron is a sweet little baked cookie made with egg whites, icing sugar, granulated sugar, almond powder, and food coloring. Often they are known for their lovely colors and delicate size among other qualities.</p>
        <a href="macroon.php"><button class="btn btn-primary" >More Details</button></a>
        
    </div>
    
</div>

<div class="row mt-3 mb-3">
    <div class="col-xl-6 col-lg-6  ">
      <img src="images/img/cupcake/cc.jpg">
    </div>
    <div class="col-xl-6 col-lg-6 bg-sucess text-center pt-5">
        <h1 style="font-family: 'Italianno', cursive; color:#DB7093;"><b>Sprinkle CupCakes  </b> </h1>
        <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
        <p align="left">A cupcake is a small cake designed to serve one person, which may be baked in a small thin paper or aluminum cup. As with larger cakes, icing and other cake decorations such as fruit and candy may be applied.</p>
        <a href="cupcakes.php"><button class="btn btn-primary  ">More Details</button></a>
    </div>
    
    
    <div class="col-xl-6 order-2 col-lg-6   ">
      <img src="images/img/cookies/aa.jpg">
    </div>
    <div class="col-xl-6 order-1 col-lg-6 bg-sucess text-center pt-5">
        <h1 style="font-family: 'Italianno', cursive; color:#DB7093;"><b>Sprinkle Cookies  </b> </h1>
        <div class="col-xl-12 col-lg-12 text-center    m-1">  <hr class="bg-danger w-50"> </div>
        <p align="left">A cookie is a baked or cooked food that is small, flat and sweet. It usually contains flour, sugar and some type of oil or fat. It may include other ingredients such as raisins, oats, chocolate chips, nuts, etc.</p>
       <a href="cookies.php"> <button class="btn btn-primary ">More Details</button></a>
    </div>
    
</div>