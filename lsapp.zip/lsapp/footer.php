
<link href="custom.css" rel="stylesheet">
<section id="footer">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                
            
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                <div class="cpt text-light text-center">
                    <p style="color:#FFFFE0;"><center> (c) 2019 copyright.Wish A Sprinkle. </center></p>
                     <a href="#"><center><img src="images/img/logo/favicon.png" > </center> </a>
                    
                </div>
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                
            </div>
            
        </div>
    </div>
</section>
            
            
              