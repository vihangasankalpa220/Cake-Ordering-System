<?php
 $id=$_GET["id"]; 
 include("dbconnection.php");
$Mem = $_SESSION["Email"] ;
    $SessionMail=$Mem;

    $sql = "DELETE FROM acc WHERE ID=$id ";

     mysqli_query($db,$sql) ;
     header("location:customerreg.php");

?>