<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
     <link rel="icon" href="images/favicon.png">
    <title>Wish A Sprinkle</title>
    
    <!--Template based on URL below-->
    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/starter-template/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet">

    <!-- Place your stylesheet here-->
    <link href="/css/stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php include("adminnav.php");?><br><br><br>
    
    
    
      
      <div class="col-xl-12 col-lg-12  p-3 h-3 mt-1 text-light rounded-lg">
          <br><br><h3 style="font-family: 'Cookie', cursive; color:#FF7F50;"><b>Contact Queries</b></h3><br>
    
                
                <table class="table table-bordered ">
                    <tr ><thead class="thead-dark">
                        <th colspan="6"><a href="addproduct.php" style="color:#DCDCDC;font-family: 'Open Sans Condensed', sans-serif; ">Queries</a></th>
                    </thead> </tr>
                    <tr><th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Query ID</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><u><center>User</center></u></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>E-mail</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Query</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Delete</u></center></th>
                    
                        
                    </tr>
         
          
          
            <?php
                    
                      
                     include("dbConnection.php");
    
              
                            $sql="SELECT * FROM contact ";
                            if($sql=mysqli_query($db,$sql)){
                                 while ($row=mysqli_fetch_array($sql))
                               {
                                     
                                $User=$row['user'];
                                $Email=$row['email'];
                                $Query=$row['query'];
                                $CID=$row['id'];
                                    
                                  
    ?>
                    
                    
                     <tr>
                      
                        
                    
                    </tr>
                  
                    <tr>  
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $CID;?></center></th>
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $User;?></center></th>
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $Email;?></center></th>
                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $Query;?></center></th> 
                        <th scope="col"> <a href=contactdel.php?id=<?php echo $CID;?>><center><button type="button" class="btn btn-outline-danger">Delete</button></center></a></th>
                                           
                                            

                                         

                                        </tr>
   
                    <?php }}?>
                     </table><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
          
             <?php include("footer.php");?>
                    
                