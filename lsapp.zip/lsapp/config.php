<?php
$hostname='localhost';
    $username= '';

$password = '';


try{
    
    $db = new POD("mysql:host=$hostname;dbname=id9336446_isapp",$username,$password);
    
    $db-> setAttribute(POD::ATTR_ERRMODE, POD::ERRMODE_EXCEPTION);
}

catch(Exception $e){
    
    echo "Connection error: ".$e->getMessage();
}


?>