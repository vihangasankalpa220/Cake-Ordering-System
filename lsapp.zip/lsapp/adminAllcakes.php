<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
     <link rel="icon" href="images/favicon.png">
    <title>Wish A Sprinkle</title>
    
    <!--Template based on URL below-->
    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/starter-template/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet">

    <!-- Place your stylesheet here-->
    <link href="/css/stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php include("adminnav.php");?><br><br><br>

      
      <div class="col-xl-12 col-lg-12  p-3 h-3 mt-1 text-light rounded-lg">
          <br><br><h3 style="font-family: 'Cookie', cursive; color:#FF7F50;"><b>All Products</b></h3><br>
                
                <table class="table table-bordered ">
                    <tr ><thead class="thead-dark">
                        <th colspan="8"><a href="addproduct.php" style="color:#DCDCDC;font-family: 'Open Sans Condensed', sans-serif; ">Add new product</a></th>
                    </thead> </tr>
                    <tr><th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>#</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><u>Product Name</u></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Product Price</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Product Quantity</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Product Image</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Product Category</u></center></th>
                         <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Update</u></center></th>
                        <th style="font-family: 'Open Sans Condensed', sans-serif;"><center><u>Delete</u></center></th>
                    </tr>
                           
                <?php
                    
                      
                     include("dbConnection.php");
    
              
                            $result="SELECT * FROM product ";
                            if($result=mysqli_query($db,$result)){
                                 while ($row=mysqli_fetch_array($result))
                               {
                                     
                                     $PName =$row["product_name"];
                                     $PPrice =$row["product_price"];
                                     $Pqty =$row["product_qty"];
                                     $PImage = $row["product_image"];
                                     $PCategory = $row["product_category"];
                                     $PID =$row["id"]; 
                                 
    ?>
                    <tr>
                      
                        
                    
                    </tr>
                  
                    <tr>  
                                          <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><?php echo $PID;?></th>
                                          <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><?php echo $PName;?></th>
                                            <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $PPrice;?></center></th>
                                            <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><?php echo $Pqty;?></center></th> 
                                        <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><center><img src="<?php  echo $row["product_image"];?> "width="55" height="55"></center></th>
                                            <th scope="col" style="font-family: 'Open Sans Condensed', sans-serif;"><?php echo $PCategory;?></th>
                                       <th scope="col"> <a href=edit.php?id=<?php echo $PID;?>><center><button type="button" class="btn btn-outline-success">Update</button></center></a></th>
                                        <th scope="col"> <a href=productdelete.php?id=<?php echo $PID;?>><center><button type="button" class="btn btn-outline-danger">Delete</button></center></a></th>
                                        


                                        </tr>
   
                    <?php }}?>
          </table>
                 

                    
                      
<?php include("footer.php");?>
                    
                    
                    
                    
                   
                  