<?php
    $id=$_GET["product_category"];
    
?>
<div class="row">
     <div class="col-xl-12 col-lg-12 p-4 bg-dark text-light text-center">
         Cake Type Name
         
         <?php
         include("dbConnection.php");
         
         $sql="select product_category from product where product_category =$id";
         
         if($res=mysqli_query($db,$sql)){
             $row=mysqli_fetch_row($res);
             echo $row[0];
             
         }
         
         
            
         
           
            
          
					?>
    </div>
</div>

<div class="row">
    <div class="col-xl-4 col-lg-4 p-4 bg-danger">
            <div class="card-deck">
          <div class="card">
            <img class="card-img-top" src="images//img/1233.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Pink Cakes</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <p class="card-text"><small class="text-muted"><button type="button" class="btn btn-primary">Order</button></small></p>
            </div>
          </div>
        </div>
    </div>
    
     <div class="col-xl-4 col-lg-4 p-4 bg-danger">
            <div class="card-deck">
          <div class="card">
            <img class="card-img-top" src="images//img/1233.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Pink Cakes</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <p class="card-text"><small class="text-muted"><button type="button" class="btn btn-primary">Order</button></small></p>
            </div>
          </div>
        </div>
    </div>
    
     <div class="col-xl-4 col-lg-4 p-4 bg-danger">
            <div class="card-deck">
          <div class="card">
            <img class="card-img-top" src="images//img/1233.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Pink Cakes</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <p class="card-text"><small class="text-muted"><button type="button" class="btn btn-primary">Order</button></small></p>
            </div>
          </div>
        </div>
    </div>
    
</div>