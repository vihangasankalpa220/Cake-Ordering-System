
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/favicon.png">
    <title>Wish A Sprinkle</title>
    
    <!--Template based on URL below-->
    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/starter-template/">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- Place your stylesheet here-->
    <link href="/css/stylesheet.css" rel="stylesheet" type="text/css">
</head>

<body>
             
             <?php include("nav.php");?><br><br><br>
   <br><br><br>
    
    <?php
    $s='';
    if (isset($_GET ['search']))  {
        $s=$_GET['search']; 
    }
    
 include("dbconnection.php");   
 session_start();
	

	//$s=$_GET['s'];
	$query="select * from product where product_name like '%$s%'";
	
	$res=mysqli_query($db,$query) or die("Product cannot be found..");

?>
    
    <div id="page">
					<!-- start content -->
							<div id="content">
								<div class="post">
										<h1 class="title"><?php echo @$_GET['id'];?></h1>
									<div class="entry">
										
										<table border="3" width="100%" >
											<?php
												$count=0;
												while($row=mysqli_fetch_assoc($res))
												{
													if($count==0)
													{
														echo '<tr>';
													}
                                                    echo '<td valign="top" width="20%" align="center">
														<a href="detail.php?id='.$row['id'].'">
														<img src="'.$row['product_image'].'" width="80" height="100">
														<br>'.$row['product_name'].'</a>
													</td>';
													$count++;							
													
													if($count==4)
													{
														echo '</tr>';
														$count=0;
													}
												}
											?>
                                            
                                            </table>
									</div>
									
								</div>
								
							</div>